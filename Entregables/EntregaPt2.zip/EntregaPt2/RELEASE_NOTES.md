# Release Notes

Fecha de subida: 12/11/2024

## Instrucciones de despliegue

Para desplegar la aplicación SOA, se debe seleccionar la opción del proyecto:
`Deploy ⭢ <composite_name> to SOA_DEV`, donde "SOA_DEV" es el nombre del
servidor SOA independiente que se ha configurado.

## Documentación del proyecto

También se puede consultar el documento [P2-DSS.pdf](./P2-DSS.pdf), donde viene
recogida la información acerca de la estructura, los componentes del
proyecto y las pruebas de los servicios orquestados.
